<?php
/* Généré par _src/wordpress.py depuis boutique.html : ne pas modifier ici. */
defined( 'ABSPATH' ) || exit;
get_header(); ?>
<section class="page-hero" style="padding-bottom: clamp(20px, 3vw, 32px)">
  <div class="wrap">
    <nav class="breadcrumb" aria-label="Fil d’Ariane"><ol><li><a href="<?php echo esc_url( moinet_url( 'accueil', '' ) ); ?>">Accueil</a></li><li aria-current="page">Boutique en ligne</li></ol></nav>
    <div class="section-head section-head--split" style="margin-bottom:0">
      <div>
        <h1 style="max-width:none">Toute la confiserie, livrée chez vous</h1>
      </div>
      <p class="muted">Paiement sécurisé par carte et livraison à domicile en Colissimo Suivi. Fabriqué à Vichy depuis 1852.</p>
    </div>
  </div>
</section>

<div data-shop data-cat="<?php echo esc_attr( is_product_taxonomy() ? get_queried_object()->slug : '' ); ?>">
  <div class="shop-toolbar">
    <div class="wrap">
      <div class="chips" role="group" aria-label="Choisir un rayon" data-rayons></div>
      <div class="toolbar-row">
        <div class="search">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></svg>
          <label for="shop-search" class="visually-hidden">Rechercher un produit</label>
          <input class="field" id="shop-search" type="search" placeholder="Rechercher : menthe, 500 g, coffret…" autocomplete="off">
        </div>
        <div class="chips chips--filters" role="group" aria-label="Filtrer" data-filtres></div>
        <p class="result-count" aria-live="polite"></p>
        <label class="sort">Trier
          <select id="shop-sort">
            <option value="pertinence">Par rayon</option>
            <option value="prix-asc">Prix croissant</option>
            <option value="prix-desc">Prix décroissant</option>
            <option value="nom">Nom (A–Z)</option>
          </select>
        </label>
      </div>
    </div>
  </div>
  <section class="section--tight" aria-labelledby="produits-title">
    <div class="wrap">
      <h2 id="produits-title" class="visually-hidden">Produits</h2>
      <div class="product-grid"><?php if ( have_posts() ) : while ( have_posts() ) : the_post(); $p = wc_get_product( get_the_ID() ); ?>
        <article class="product"><div class="product-img"><?php echo $p ? $p->get_image( 'woocommerce_thumbnail' ) : ''; ?></div><div class="product-body"><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><div class="product-foot"><span class="price"><?php echo $p ? wp_kses_post( $p->get_price_html() ) : ''; ?></span></div></div></article>
      <?php endwhile; endif; ?></div>
      <p class="shop-note" style="margin-top:2rem">Le bouton panier ajoute le produit à votre panier sur confiserie-moinet.fr. Prix TTC, frais de port calculés au panier. <a href="<?php echo esc_url( home_url( '/conditions-generales-de-ventes/' ) ); ?>">Conditions générales de vente</a>.</p>
    </div>
  </section>
</div>
<?php get_footer();
