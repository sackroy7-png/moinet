</main>
<div class="vichy vichy--rouge" aria-hidden="true"></div>
<footer class="site-footer">
  <div class="wrap footer-top">
    <div class="footer-brand">
      <img src="<?php echo esc_url( moinet_asset( 'img/logo-moinet.png' ) ); ?>" alt="Moinet Confiseur" width="350" height="234" loading="lazy">
      <p>La plus ancienne confiserie de Vichy toujours en activité. Fabrique familiale, artisanale et indépendante depuis 1852.</p>
      <div class="socials">
        <a href="https://www.facebook.com/maisonmoinet/" aria-label="Maison Moinet sur Facebook" rel="noopener"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M13.5 21v-7.5h2.6l.4-3h-3V8.6c0-.9.3-1.5 1.5-1.5h1.6V4.4c-.3 0-1.2-.1-2.3-.1-2.3 0-3.8 1.4-3.8 3.9v2.3H7.9v3h2.6V21h3Z"/></svg></a>
        <a href="https://www.instagram.com/maisonmoinet/" aria-label="Maison Moinet sur Instagram" rel="noopener"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><rect x="3.5" y="3.5" width="17" height="17" rx="4.5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r=".9" fill="currentColor" stroke="none"/></svg></a>
      </div>
      <div class="footer-partner">
        <img src="<?php echo esc_url( moinet_asset( 'img/region-aura.png' ) ); ?>" alt="Partenaire : La Région Auvergne-Rhône-Alpes" width="300" height="150" loading="lazy">
      </div>
    </div>
    <div>
      <h2>La Maison</h2>
      <ul>
        <li><a href="<?php echo esc_url( moinet_url( 'maison', '' ) ); ?>">Présentation</a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'maison', '#histoire' ) ); ?>">Histoire de la maison</a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'savoir-faire', '' ) ); ?>">Notre savoir-faire</a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'magasins', '' ) ); ?>">Nos boutiques</a></li>
        <li><a href="<?php echo esc_url( home_url( '/recettes/' ) ); ?>">Idées recettes</a></li>
      </ul>
    </div>
    <div>
      <h2>Boutique en ligne</h2>
      <ul>
        <li><a href="<?php echo esc_url( moinet_url( 'boutique', '?cat=pastilles' ) ); ?>">Pastilles du Bassin de Vichy</a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'boutique', '?cat=bonbons-glaces' ) ); ?>">Bonbons glacés</a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'boutique', '?cat=pate-de-fruits' ) ); ?>">Pâtes de fruits</a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'boutique', '?cat=chocolats' ) ); ?>">Chocolats</a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'boutique', '?cat=caramels-nougats' ) ); ?>">Caramels &amp; nougats</a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'boutique', '?cat=sucres-cuits' ) ); ?>">Sucres d’orge</a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'boutique', '?cat=coffrets-souvenirs' ) ); ?>">Idées cadeaux</a></li>
      </ul>
    </div>
    <div>
      <h2>Service client</h2>
      <ul>
        <li><a href="mailto:contact@confiserie-moinet.fr">contact@confiserie-moinet.fr</a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'contact', '' ) ); ?>">Nous écrire</a></li>
        <li><a href="<?php echo esc_url( home_url( '/mon-compte/' ) ); ?>">Mon compte</a></li>
        <li><a href="<?php echo esc_url( home_url( '/mon-compte/orders/' ) ); ?>">Mes commandes</a></li>
        <li><a href="<?php echo esc_url( home_url( '/conditions-generales-de-ventes/' ) ); ?>">Conditions générales de vente</a></li>
      </ul>
    </div>
  </div>
  <div class="wrap footer-bottom">
    <p>© <?php echo esc_html( wp_date( 'Y' ) ); ?> Confiserie Moinet, Vichy</p>
    <ul>
      <li><a href="<?php echo esc_url( home_url( '/mentions-legales/' ) ); ?>">Mentions légales</a></li>
      <li><a href="<?php echo esc_url( home_url( '/conditions-generales-de-ventes/' ) ); ?>">CGV</a></li>
      <li><button type="button" class="link-btn" data-cookies hidden>Gestion des cookies</button></li>
    </ul>
  </div>
  <p class="footer-word" aria-hidden="true"><span>Maison</span> <span>Moinet</span></p>
</footer>
<nav class="action-bar" aria-label="Actions rapides">
  <a class="btn" href="<?php echo esc_url( moinet_url( 'boutique', '' ) ); ?>">Commander en ligne</a>
  <a class="btn btn--ghost" href="<?php echo esc_url( moinet_url( 'magasins', '' ) ); ?>">Voir les boutiques</a>
</nav>
<?php wp_footer(); ?>
</body>
</html>
