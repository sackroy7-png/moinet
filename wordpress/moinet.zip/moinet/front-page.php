<?php
/* Généré par _src/wordpress.py depuis index.html : ne pas modifier ici. */
defined( 'ABSPATH' ) || exit;
get_header(); ?>
<div class="opening">
<section class="hero hero--im" data-enter aria-labelledby="hero-title">
  <div class="hero-frame">
    <img class="hero-photo" src="<?php echo esc_url( moinet_asset( 'img/hero.webp' ) ); ?>" srcset="<?php echo esc_url( moinet_asset( 'img/hero-900.webp' ) ); ?> 900w, <?php echo esc_url( moinet_asset( 'img/hero-1400.webp' ) ); ?> 1400w, <?php echo esc_url( moinet_asset( 'img/hero.webp' ) ); ?> 2000w" sizes="100vw" width="2000" height="1250" fetchpriority="high"
         alt="Intérieur de la confiserie Moinet : étagères de boîtes en fer bleues et rouges, sachets de bonbons et paniers garnis.">
    <div class="hero-copy">
      <h1 id="hero-title">Confiserie artisanale à Vichy, en famille depuis&nbsp;1852.</h1>
      <div class="hero-ctas">
        <a class="btn" href="<?php echo esc_url( moinet_url( 'boutique', '' ) ); ?>">Commander en ligne</a>
        <a class="btn btn--ghost" href="<?php echo esc_url( moinet_url( 'magasins', '' ) ); ?>">Trouver une boutique</a>
      </div>
      <p class="hero-visit"><strong>Boutique historique</strong>, 4, rue de la Source de l’Hôpital à Vichy. Du lundi au samedi, 9h30–12h et 14h30–19h.</p>
    </div>
  </div>
  <aside class="hero-card" aria-labelledby="new-title">
    <p class="sticker">Nouveau</p>
    <div class="hero-card-in">
      <img src="<?php echo esc_url( moinet_asset( 'img/shop-pastillerie.webp' ) ); ?>" width="765" height="1020" alt="Entrée de la Pastillerie Moinet, rue Président Roosevelt à Vichy.">
      <h2 id="new-title">La Pastillerie Moinet</h2>
      <p>Une boutique dédiée aux pastilles et à l’univers Moinet, ouverte en mars 2026 au 2, rue Président Roosevelt à Vichy.</p>
      <a class="btn btn--sm btn--ink" href="<?php echo esc_url( moinet_url( 'magasins', '#pastillerie' ) ); ?>">Voir l’adresse</a>
    </div>
  </aside>
</section>

<section class="stage" data-stage data-flavor="menthe" aria-labelledby="pastille-title">
  <div class="stage-pin">
    <div class="stage-bg" aria-hidden="true"><i class="stage-iris"></i></div>
    <div class="wrap stage-grid" data-flavor-picker>
      <div class="stage-copy">
        <h2 id="pastille-title">La pastille du Bassin de Vichy</h2>
        <p class="lead">En 1932, Rémi Moinet achète la Source Roger, à Hauterive, pour en extraire les sels minéraux. Aujourd’hui, les pastilles représentent 80&nbsp;% de notre production.</p>
      </div>
      <div class="stage-visual">
        <span class="pastille-shadow" aria-hidden="true"></span>
        <img class="pastille-still" src="<?php echo esc_url( moinet_asset( 'img/pastille.webp' ) ); ?>" width="720" height="720" alt="Pastille octogonale blanche gravée « Bassin de Vichy ».">
        <canvas class="pastille-canvas" aria-hidden="true"></canvas>
      </div>
      <fieldset class="flavors">
        <legend>Choisissez votre parfum</legend>
        <button type="button" class="flavor" data-flavor="menthe" aria-pressed="true" style="--f:var(--menthe)"><span class="dot" aria-hidden="true"></span>Menthe</button>
        <button type="button" class="flavor" data-flavor="citron" aria-pressed="false" style="--f:var(--citron)"><span class="dot" aria-hidden="true"></span>Citron</button>
        <button type="button" class="flavor" data-flavor="anis" aria-pressed="false" style="--f:var(--anis)"><span class="dot" aria-hidden="true"></span>Anis</button>
        <button type="button" class="flavor" data-flavor="orange" aria-pressed="false" style="--f:var(--orange)"><span class="dot" aria-hidden="true"></span>Orange</button>
        <button type="button" class="flavor" data-flavor="sans-sucre" aria-pressed="false" style="--f:var(--sans-sucre)"><span class="dot" aria-hidden="true"></span>Sans sucre</button>
      </fieldset>
      <div class="stage-shop">
        <p class="rail-status" aria-live="polite"></p>
        <div class="flavor-grid"></div>
        <a class="link-arrow" data-flavor-link href="<?php echo esc_url( moinet_url( 'boutique', '?cat=pastilles' ) ); ?>">Voir toutes les pastilles</a>
      </div>
    </div>
  </div>
</section>
</div>

<section class="manifesto" aria-labelledby="manifeste-title" data-moment="word-highlight">
  <div class="wrap">
    <h2 id="manifeste-title" class="manifesto-text" data-words>Sept générations de confiseurs&nbsp;: pastilles du Bassin de Vichy <img class="chip-img" src="<?php echo esc_url( moinet_asset( 'img/chip-pastilles.webp' ) ); ?>" alt="" width="300" height="160" loading="lazy">, bonbons glacés façonnés à la main <img class="chip-img" src="<?php echo esc_url( moinet_asset( 'img/chip-bonbons-glaces.webp' ) ); ?>" alt="" width="300" height="160" loading="lazy">, pâtes de fruits d’Auvergne <img class="chip-img" src="<?php echo esc_url( moinet_asset( 'img/chip-pates-de-fruits.webp' ) ); ?>" alt="" width="300" height="160" loading="lazy"> et boîtes en fer à collectionner <img class="chip-img" src="<?php echo esc_url( moinet_asset( 'img/chip-boites.webp' ) ); ?>" alt="" width="300" height="160" loading="lazy">.</h2>
  </div>
  <div class="word-band" data-marquee aria-hidden="true"><div class="marquee-track">
    <span>Pastilles du Bassin de Vichy</span><span>Sucres d’orge de Vichy</span><span>Bonbons glacés du pays bourbonnais</span><span>Pâtes de fruits d’Auvergne</span><span>Menthe fondante</span><span>Gommes véritables</span><span>Chocolats</span><span>Caramels, nougats, pralines</span>
  </div></div>
  <div class="wrap marquee-ctrl"><button type="button" class="marquee-toggle" data-marquee-toggle aria-pressed="false"><svg viewBox="0 0 16 16" aria-hidden="true"><rect x="3" y="2" width="3.5" height="12"/><rect x="9.5" y="2" width="3.5" height="12"/></svg><span>Mettre en pause</span></button></div>
</section>

<section class="section section--paper specialites" aria-labelledby="specialites-title">
  <div class="wrap">
    <div class="section-head section-head--split">
      <h2 id="specialites-title">Les spécialités d’Auvergne et du Bourbonnais</h2>
      <p class="muted">Sucres d’orge de Vichy, bonbons glacés du pays bourbonnais, pâtes de fruits pure pulpe d’Auvergne, caramels, nougats, pralines, chocolats&nbsp;: un savoir-faire transmis de génération en génération.</p>
    </div>
    <div class="mosaic" data-parallax>
      <a class="tile tile--xl" href="<?php echo esc_url( moinet_url( 'boutique', '?cat=pastilles' ) ); ?>">
        <img src="<?php echo esc_url( moinet_asset( 'img/cat-pour-offrir.webp' ) ); ?>" alt="" loading="lazy" width="1300" height="1229">
        <span class="tile-label"><span>Menthe, citron, anis, orange</span><strong>Pastilles du Bassin de Vichy</strong></span>
      </a>
      <a class="tile" href="<?php echo esc_url( moinet_url( 'boutique', '?cat=bonbons-glaces' ) ); ?>">
        <img src="<?php echo esc_url( moinet_asset( 'img/cat-bonbons-glaces.webp' ) ); ?>" alt="" loading="lazy" width="1200" height="600">
        <span class="tile-label"><span>Façonnés à la main</span><strong>Bonbons glacés</strong></span>
      </a>
      <a class="tile tile--tall" href="<?php echo esc_url( moinet_url( 'boutique', '?q=carreaux' ) ); ?>">
        <img src="<?php echo esc_url( moinet_asset( 'img/cat-carreaux-vichy.webp' ) ); ?>" alt="" loading="lazy" width="1300" height="946">
        <span class="tile-label"><span>Boîtes, sacs, torchons</span><strong>Carreaux Vichy</strong></span>
      </a>
      <a class="tile" href="<?php echo esc_url( moinet_url( 'boutique', '?cat=chocolats' ) ); ?>">
        <img src="<?php echo esc_url( moinet_asset( 'img/cat-chocolats.webp' ) ); ?>" alt="" loading="lazy" width="1100" height="734">
        <span class="tile-label"><span>Ballotins, mendiants</span><strong>Chocolats</strong></span>
      </a>
      <a class="tile tile--wide" href="<?php echo esc_url( moinet_url( 'boutique', '?cat=sucres-cuits' ) ); ?>">
        <img src="<?php echo esc_url( moinet_asset( 'img/cat-sucres-cuits.webp' ) ); ?>" alt="" loading="lazy" width="1200" height="600">
        <span class="tile-label"><span>Coquelicot, violette, verveine</span><strong>Sucres d’orge de Vichy</strong></span>
      </a>
      <a class="tile" href="<?php echo esc_url( moinet_url( 'boutique', '?cat=pate-de-fruits' ) ); ?>">
        <img src="<?php echo esc_url( moinet_asset( 'img/cat-pate-de-fruits.webp' ) ); ?>" alt="" loading="lazy" width="800" height="533">
        <span class="tile-label"><span>Pure pulpe d’Auvergne</span><strong>Pâtes de fruits</strong></span>
      </a>
      <a class="tile" href="<?php echo esc_url( moinet_url( 'boutique', '?cat=caramels-nougats' ) ); ?>">
        <img src="<?php echo esc_url( moinet_asset( 'img/cat-caramels-nougats.webp' ) ); ?>" alt="" loading="lazy" width="1200" height="600">
        <span class="tile-label"><span>Recettes traditionnelles</span><strong>Caramels &amp; nougats</strong></span>
      </a>
      <a class="tile tile--wide" href="<?php echo esc_url( moinet_url( 'boutique', '?cat=gommes' ) ); ?>">
        <img src="<?php echo esc_url( moinet_asset( 'img/cat-gommes.webp' ) ); ?>" alt="" loading="lazy" width="1200" height="600">
        <span class="tile-label"><span>Réglisse, miel, menthol</span><strong>Gommes &amp; guimauves</strong></span>
      </a>
      <a class="tile tile--wide" href="<?php echo esc_url( moinet_url( 'boutique', '?cat=coffrets-souvenirs' ) ); ?>">
        <img src="<?php echo esc_url( moinet_asset( 'img/cat-assortiments.webp' ) ); ?>" alt="" loading="lazy" width="800" height="533">
        <span class="tile-label"><span>Coffrets et boîtes en fer</span><strong>Idées cadeaux</strong></span>
      </a>
    </div>
  </div>
</section>

<section class="atelier" aria-labelledby="savoir-title">
  <div class="atelier-track" data-expand>
  <div class="atelier-pin">
    <div class="atelier-window">
      <img src="<?php echo esc_url( moinet_asset( 'img/savoir-tdl.webp' ) ); ?>" width="1024" height="682" loading="lazy"
           alt="Main d’un confiseur trempant des bonbons un à un dans un poêlon en cuivre, à côté d’une plaque de bonbons alignés.">
    </div>
    <div class="atelier-copy">
      <h2 id="savoir-title">Des bonbons glacés façonnés un à un, comme des bijoux</h2>
      <p>Nos produits sont garantis « made in France », et même « made in Auvergne ». La réalisation des bonbons glacés, très technique, demande plusieurs étapes de façonnage à la main.</p>
      <a class="btn btn--light" href="<?php echo esc_url( moinet_url( 'savoir-faire', '' ) ); ?>">Découvrir notre savoir-faire</a>
    </div>
  </div>
  </div>
  <div class="wrap atelier-facts">
    <ul class="checks">
      <li>Bonbons glacés, nougats, caramels et pralines élaborés de manière traditionnelle</li>
      <li>Chocolats façonnés artisanalement&nbsp;: tablettes, mendiants, ballotins</li>
      <li>Un atelier historique à Vichy et deux sites de production à Hauterive</li>
    </ul>
  </div>
</section>

<section class="section histoire" aria-labelledby="histoire-title">
  <div class="wrap heritage">
    <div class="heritage-media">
      <img class="cut" src="<?php echo esc_url( moinet_asset( 'img/histoire-4.webp' ) ); ?>" width="1300" height="909" loading="lazy"
           alt="Photographie d’archive : un confiseur Moinet au travail dans l’atelier.">
    </div>
    <div>
      <h2 id="histoire-title">L’histoire d’une famille, de 1852 à la septième génération</h2>
      <p class="muted">La Maison Moinet est toujours dirigée par la même famille. Son histoire accompagne celle de Vichy, la Reine des villes d’eaux.</p>
      <ol class="timeline">
        <li><time datetime="1852">1852</time><div><h3>La confiserie voit le jour</h3><p>Jules Rondepierre et Marie Madeleine Moinet s’installent rue de la Source de l’Hôpital. L’atelier de l’arrière-boutique en est encore le cœur.</p></div></li>
        <li><time datetime="1932">1932</time><div><h3>La Source Roger</h3><p>Rémi Moinet acquiert la source à Hauterive et lance ses propres pastilles du Bassin de Vichy.</p></div></li>
        <li><time datetime="1998">1998</time><div><h3>La pastillerie du Bioparc</h3><p>Une nouvelle unité de production s’implante à Hauterive, à deux pas de l’usine historique.</p></div></li>
        <li><time datetime="2017">2017</time><div><h3>La septième génération</h3><p>Lucas Michaille prend la responsabilité de la production, aux côtés d’Elisabeth et Gilles.</p></div></li>
        <li><time datetime="2026-03">2026</time><div><h3>La Pastillerie Moinet</h3><p>Une boutique dédiée aux pastilles ouvre rue Président Roosevelt, à Vichy.</p></div></li>
      </ol>
      <a class="btn btn--ghost" href="<?php echo esc_url( moinet_url( 'maison', '#histoire' ) ); ?>">Lire l’histoire de la maison</a>
    </div>
  </div>
  <div class="gravures" data-drift>
    <img src="<?php echo esc_url( moinet_asset( 'img/gravures.webp' ) ); ?>" width="2000" height="348" loading="lazy"
         alt="Cinq gravures en noir et blanc : une confiserie à colombages, un verger, un atelier, une source jaillissante et la devanture « Les bonbons de H. Moinet ».">
  </div>
</section>

<section class="section section--ink griffe" id="boites" aria-labelledby="griffe-title">
  <div class="wrap">
    <div class="section-head section-head--split">
      <h2 id="griffe-title">Les boîtes Moinet, et ce qu’elles renferment</h2>
      <p>Dès les années 1930, Rémi Moinet dessine boîtes et prospectus et commande au graveur Paul Devaux des modèles qui représentent Vichy à différentes époques. Ces boîtes en vente aujourd’hui gardent ce goût du décor, remplies de nos spécialités.</p>
    </div>
  </div>
  <div class="fan fan--boites" data-fan>
    <div class="fan-ambient" aria-hidden="true"></div>
    <ul class="fan-stage">
      <li class="fan-item"><span class="fan-shot"><img src="<?php echo esc_url( moinet_asset( 'img/boite-enluminures.webp' ) ); ?>" alt="Boîte en fer « Enluminures » ouverte sur des pastilles et des sucres d’orge." loading="lazy" width="800" height="533"></span>
        <div class="fan-info" data-box="11784"><h3>Boîte « Enluminures »</h3><p>Pastilles du Bassin de Vichy et sucres d’orge. Petit, moyen ou grand modèle.</p><p class="fan-price" data-box-price>dès 14,80&nbsp;€</p><a class="btn btn--sm" data-box-link href="<?php echo esc_url( moinet_url( 'boutique', '?q=enluminures' ) ); ?>">Voir la boîte</a></div></li>
      <li class="fan-item"><span class="fan-shot"><img src="<?php echo esc_url( moinet_asset( 'img/boite-bourbonnaise.webp' ) ); ?>" alt="Boîte ovale « Bourbonnaise » remplie de bonbons glacés." loading="lazy" width="945" height="874"></span>
        <div class="fan-info" data-box="1464"><h3>Boîte « Bourbonnaise »</h3><p>Bonbons glacés du pays bourbonnais, façonnés à la main. 250&nbsp;g, 500&nbsp;g ou 650&nbsp;g.</p><p class="fan-price" data-box-price>dès 27,20&nbsp;€</p><a class="btn btn--sm" data-box-link href="<?php echo esc_url( moinet_url( 'boutique', '?q=bourbonnaise' ) ); ?>">Voir la boîte</a></div></li>
      <li class="fan-item"><span class="fan-shot"><img src="<?php echo esc_url( moinet_asset( 'img/boite-charette.webp' ) ); ?>" alt="Boîte « Charette » ouverte sur un assortiment de spécialités de Vichy." loading="lazy" width="800" height="533"></span>
        <div class="fan-info" data-box="612"><h3>Boîte « Charette »</h3><p>Pastilles, sucres d’orge et guimauves, ou pastilles, sucres d’orge et fraises et myrtilles.</p><p class="fan-price" data-box-price>25,90&nbsp;€</p><a class="btn btn--sm" data-box-link href="<?php echo esc_url( moinet_url( 'boutique', '?q=charette' ) ); ?>">Voir la boîte</a></div></li>
      <li class="fan-item"><span class="fan-shot"><img src="<?php echo esc_url( moinet_asset( 'img/boite-donneuse-d-eau.webp' ) ); ?>" alt="Coffret « Donneuse d’Eau » et son assortiment de spécialités." loading="lazy" width="1100" height="733"></span>
        <div class="fan-info" data-box="12511"><h3>Coffret « Donneuse d’Eau »</h3><p>Mini pastilles, sucres d’orge et bonbons glacés. 395&nbsp;g.</p><p class="fan-price" data-box-price>24,90&nbsp;€</p><a class="btn btn--sm" data-box-link href="<?php echo esc_url( moinet_url( 'boutique', '?q=donneuse' ) ); ?>">Voir la boîte</a></div></li>
      <li class="fan-item"><span class="fan-shot"><img src="<?php echo esc_url( moinet_asset( 'img/boite-lions.webp' ) ); ?>" alt="Quatre boîtes « Lions » de pastilles, bleue, jaune, verte et rouge." loading="lazy" width="1100" height="733"></span>
        <div class="fan-info" data-box="11942"><h3>Boîte « Lions »</h3><p>500&nbsp;g de pastilles du Bassin de Vichy&nbsp;: menthe, citron, anis ou orange, chaque parfum dans sa couleur.</p><p class="fan-price" data-box-price>16,80&nbsp;€</p><a class="btn btn--sm" data-box-link href="<?php echo esc_url( moinet_url( 'boutique', '?q=lions' ) ); ?>">Voir la boîte</a></div></li>
      <li class="fan-item"><span class="fan-shot"><img src="<?php echo esc_url( moinet_asset( 'img/boite-verger.webp' ) ); ?>" alt="Boîte « Verger » de pâtes de fruits." loading="lazy" width="1100" height="733"></span>
        <div class="fan-info" data-box="9289"><h3>Boîte « Verger »</h3><p>Pâtes de fruits. 280&nbsp;g.</p><p class="fan-price" data-box-price>21,80&nbsp;€</p><a class="btn btn--sm" data-box-link href="<?php echo esc_url( moinet_url( 'boutique', '?q=verger' ) ); ?>">Voir la boîte</a></div></li>
      <li class="fan-item"><span class="fan-shot"><img src="<?php echo esc_url( moinet_asset( 'img/boite-prestige.webp' ) ); ?>" alt="Boîte Prestige « Vichy Époque Romantique » garnie de chocolats." loading="lazy" width="825" height="1100"></span>
        <div class="fan-info" data-box="12521"><h3>Boîte Prestige « Vichy Époque Romantique »</h3><p>Assortiment de chocolats. 550&nbsp;g.</p><p class="fan-price" data-box-price>68,90&nbsp;€</p><a class="btn btn--sm" data-box-link href="<?php echo esc_url( moinet_url( 'boutique', '?q=prestige' ) ); ?>">Voir la boîte</a></div></li>
      <li class="fan-item"><span class="fan-shot"><img src="<?php echo esc_url( moinet_asset( 'img/boite-vues-de-vichy.webp' ) ); ?>" alt="Boîte « Vues de Vichy » de pâtes de fruits d’Auvergne." loading="lazy" width="1100" height="1011"></span>
        <div class="fan-info" data-box="11887"><h3>Boîte « Vues de Vichy »</h3><p>Pâtes de fruits d’Auvergne. 220&nbsp;g.</p><p class="fan-price" data-box-price>6,20&nbsp;€</p><a class="btn btn--sm" data-box-link href="<?php echo esc_url( moinet_url( 'boutique', '?q=vues+de+vichy' ) ); ?>">Voir la boîte</a></div></li>
      <li class="fan-item"><span class="fan-shot"><img src="<?php echo esc_url( moinet_asset( 'img/boite-source-roger.webp' ) ); ?>" alt="Boîte ronde « Source Roger » de pastilles menthe." loading="lazy" width="640" height="624"></span>
        <div class="fan-info" data-box="14638"><h3>Boîte ronde « Source Roger »</h3><p>Pastilles du Bassin de Vichy à la menthe. 125&nbsp;g.</p><p class="fan-price" data-box-price>8,50&nbsp;€</p><a class="btn btn--sm" data-box-link href="<?php echo esc_url( moinet_url( 'boutique', '?q=source+roger' ) ); ?>">Voir la boîte</a></div></li>
    </ul>
    <div class="fan-names" role="group" aria-label="Choisir une boîte">
      <button type="button" class="fan-name" aria-pressed="true">Enluminures</button>
      <button type="button" class="fan-name" aria-pressed="false">Bourbonnaise</button>
      <button type="button" class="fan-name" aria-pressed="false">Charette</button>
      <button type="button" class="fan-name" aria-pressed="false">Donneuse d’Eau</button>
      <button type="button" class="fan-name" aria-pressed="false">Lions</button>
      <button type="button" class="fan-name" aria-pressed="false">Verger</button>
      <button type="button" class="fan-name" aria-pressed="false">Époque Romantique</button>
      <button type="button" class="fan-name" aria-pressed="false">Vues de Vichy</button>
      <button type="button" class="fan-name" aria-pressed="false">Source Roger</button>
    </div>
    <div class="fan-details" aria-live="polite"></div>
    <div class="fan-nav">
      <button type="button" data-fan-prev aria-label="Boîte précédente"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M14.5 5.5 8 12l6.5 6.5"/></svg></button>
      <button type="button" data-fan-next aria-label="Boîte suivante"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M9.5 5.5 16 12l-6.5 6.5"/></svg></button>
    </div>
  </div>
</section>

<div class="vichy" aria-hidden="true"></div>
<section class="section boutiques" aria-labelledby="boutiques-title">
  <div class="wrap boutiques-grid">
    <div class="boutiques-copy">
      <h2 id="boutiques-title">Six boutiques Moinet, de Vichy à l’île Saint-Louis</h2>
      <p>Depuis toujours, la Maison Moinet est à la fois fabricant et commerçant. Retrouvez nos douceurs dans la boutique historique de 1852, à Clermont-Ferrand et à Paris.</p>
      <ul class="store-list" data-stores>
        <li><a href="<?php echo esc_url( moinet_url( 'magasins', '#vichy-historique' ) ); ?>"><span class="city">Vichy</span><strong>Confiserie Moinet</strong><span class="addr">4, rue de la Source de l’Hôpital, la boutique historique</span></a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'magasins', '#cote-sucre' ) ); ?>"><span class="city">Vichy</span><strong>Côté Sucré</strong><span class="addr">11, rue Georges-Clemenceau</span></a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'magasins', '#pastillerie' ) ); ?>"><span class="city">Vichy</span><strong>Pastillerie Moinet</strong><span class="addr">2, rue Président Roosevelt</span></a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'magasins', '#galerie-des-glaces' ) ); ?>"><span class="city">Vichy</span><strong>La Galerie des Glaces</strong><span class="addr">1, rue Georges-Clemenceau, glaces artisanales</span></a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'magasins', '#clermont' ) ); ?>"><span class="city">Clermont-Ferrand</span><strong>Confiserie Moinet</strong><span class="addr">1, place Royale, décor Art nouveau</span></a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'magasins', '#paris' ) ); ?>"><span class="city">Paris</span><strong>Maison Moinet</strong><span class="addr">45, rue Saint-Louis-en-l’Île</span></a></li>
      </ul>
      <a class="btn btn--light" href="<?php echo esc_url( moinet_url( 'magasins', '' ) ); ?>">Voir les adresses et horaires</a>
    </div>
    <div class="store-frame" aria-hidden="true">
      <img class="is-on" src="<?php echo esc_url( moinet_asset( 'img/shop-vichy.webp' ) ); ?>" alt="" loading="lazy" width="1200" height="800">
      <img src="<?php echo esc_url( moinet_asset( 'img/shop-cotesucre.webp' ) ); ?>" alt="" loading="lazy" width="1200" height="800">
      <img src="<?php echo esc_url( moinet_asset( 'img/shop-pastillerie.webp' ) ); ?>" alt="" loading="lazy" width="765" height="1020">
      <img src="<?php echo esc_url( moinet_asset( 'img/shop-glaces.webp' ) ); ?>" alt="" loading="lazy" width="1200" height="800">
      <img src="<?php echo esc_url( moinet_asset( 'img/shop-clermont.webp' ) ); ?>" alt="" loading="lazy" width="1200" height="800">
      <img src="<?php echo esc_url( moinet_asset( 'img/shop-paris.webp' ) ); ?>" alt="" loading="lazy" width="1200" height="800">
    </div>
  </div>
</section>

<section class="section section--paper presse" aria-labelledby="presse-title">
  <div class="wrap quote">
    <h2 id="presse-title" class="quote-title">Le Petit Futé, à propos de la Maison Moinet</h2>
    <blockquote><p>C’est dans cette confiserie ayant gardé son âme d’antan que l’on trouve la célèbre pastille du Bassin de Vichy en versions anis, citron, orange et menthe.</p></blockquote>
    <p class="quote-source">Le Petit Futé, 2026 — <a href="https://www.petitfute.com/v3514-vichy-03200/c650-produits-gourmands-vins/c1107-pains-gateaux-chocolats-glaces/c669-confiserie-dragees/1638076-confiserie-maison-moinet.html" rel="noopener">Lire l’article du Petit Futé</a></p>
  </div>
</section>

<section class="section recettes" aria-labelledby="recettes-title">
  <div class="wrap">
    <div class="section-head section-head--split">
      <h2 id="recettes-title">Des recettes à la pastille de Vichy</h2>
      <p class="muted">Desserts frais, meringues ou millefeuille&nbsp;: la pastille du Bassin de Vichy passe en cuisine. <a class="link-arrow" href="<?php echo esc_url( home_url( '/recettes/' ) ); ?>">Voir toutes les recettes</a></p>
    </div>
    <div class="recipes">
      <a class="recipe" href="<?php echo esc_url( home_url( '/recettes/' ) ); ?>">
        <span class="recipe-img"><img src="<?php echo esc_url( moinet_asset( 'img/recette-1.webp' ) ); ?>" alt="" loading="lazy" width="700" height="490"></span>
        <h3>Meringues aux pastilles du Bassin de Vichy</h3><p class="muted small">À la menthe, anis, citron ou orange</p>
      </a>
      <a class="recipe" href="<?php echo esc_url( home_url( '/recettes/' ) ); ?>">
        <span class="recipe-img"><img src="<?php echo esc_url( moinet_asset( 'img/recette-4.webp' ) ); ?>" alt="" loading="lazy" width="700" height="467"></span>
        <h3>Millefeuille moelleux pastille et miel d’Auvergne</h3><p class="muted small">Pâte feuilletée, crème et miel</p>
      </a>
      <a class="recipe" href="<?php echo esc_url( home_url( '/recettes/' ) ); ?>">
        <span class="recipe-img"><img src="<?php echo esc_url( moinet_asset( 'img/recette-7.webp' ) ); ?>" alt="" loading="lazy" width="700" height="467"></span>
        <h3>Salade de framboises rafraîchies à la pastille</h3><p class="muted small">Fraîcheur et fruits rouges</p>
      </a>
    </div>
  </div>
</section>

<section class="cta-band" aria-labelledby="cta-title">
  <img src="<?php echo esc_url( moinet_asset( 'img/eboutique.webp' ) ); ?>" alt="" loading="lazy" width="1600" height="500">
  <div class="wrap">
    <div>
      <h2 id="cta-title">Plus de 150 douceurs, livrées chez vous</h2>
      <p>Des sachets de pastilles aux coffrets cadeaux. Paiement sécurisé par CB, Visa ou Mastercard, expédition en Colissimo Suivi.</p>
    </div>
    <a class="btn btn--light" href="<?php echo esc_url( moinet_url( 'boutique', '' ) ); ?>">Commander en ligne</a>
  </div>
  <div class="close-marquee" data-marquee aria-hidden="true"><div class="marquee-track"><span>Vichy</span><span>Clermont-Ferrand</span><span>Paris</span><span>Vichy</span><span>Clermont-Ferrand</span><span>Paris</span></div></div>
  <div class="wrap marquee-ctrl marquee-ctrl--light"><button type="button" class="marquee-toggle" data-marquee-toggle aria-pressed="false"><svg viewBox="0 0 16 16" aria-hidden="true"><rect x="3" y="2" width="3.5" height="12"/><rect x="9.5" y="2" width="3.5" height="12"/></svg><span>Mettre en pause</span></button></div>
</section>
<?php get_footer();
