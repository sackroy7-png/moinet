<?php defined( 'ABSPATH' ) || exit; ?><!doctype html>
<html <?php language_attributes(); ?> data-type="place">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#contenu">Aller au contenu</a>
<aside class="topbar" aria-label="Informations pratiques"><span class="tb-long">Livraison à domicile en Colissimo Suivi et paiement sécurisé. </span><a href="<?php echo esc_url( moinet_url( 'magasins', '' ) ); ?>">6 boutiques à Vichy, Clermont-Ferrand et Paris</a></aside>
<header class="site-header">
  <div class="wrap header-inner">
    <a class="brand" href="<?php echo esc_url( moinet_url( 'accueil', '' ) ); ?>" aria-label="Maison Moinet, confiseur à Vichy depuis 1852 — accueil">
      <img src="<?php echo esc_url( moinet_asset( 'img/logo-moinet.png' ) ); ?>" alt="" width="350" height="234">
      <span class="brand-tag">Confiseur à Vichy<br>depuis 1852</span>
    </a>
    <nav class="main-nav" aria-label="Navigation principale">
      <ul>
        <li><a href="<?php echo esc_url( moinet_url( 'maison', '' ) ); ?>"<?php moinet_current( 'maison' ); ?>>La Maison</a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'savoir-faire', '' ) ); ?>"<?php moinet_current( 'savoir-faire' ); ?>>Savoir-faire</a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'boutique', '' ) ); ?>"<?php moinet_current( 'boutique' ); ?>>Boutique en ligne</a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'magasins', '' ) ); ?>"<?php moinet_current( 'magasins' ); ?>>Nos boutiques</a></li>
        <li><a href="<?php echo esc_url( moinet_url( 'contact', '' ) ); ?>"<?php moinet_current( 'contact' ); ?>>Contact</a></li>
      </ul>
    </nav>
    <div class="header-actions">
      <a class="icon-btn" href="<?php echo esc_url( home_url( '/mon-compte/' ) ); ?>" aria-label="Mon compte"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="12" cy="8.5" r="3.8"/><path d="M4.5 20c1.2-3.6 4-5.5 7.5-5.5s6.3 1.9 7.5 5.5"/></svg></a>
      <a class="icon-btn" href="<?php echo esc_url( home_url( '/panier/' ) ); ?>" aria-label="Panier"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M5 8h14l-1.2 11.2a1 1 0 0 1-1 .8H7.2a1 1 0 0 1-1-.8L5 8Z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/></svg></a>
      <a class="btn btn--sm header-shop" href="<?php echo esc_url( moinet_url( 'boutique', '' ) ); ?>">Commander</a>
      <button class="icon-btn nav-toggle" type="button" aria-expanded="false" aria-controls="mobile-nav" aria-label="Ouvrir le menu"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M3.5 7h17M3.5 12h17M3.5 17h17"/></svg></button>
    </div>
  </div>
</header>
<div class="mobile-nav" id="mobile-nav" role="dialog" aria-modal="true" aria-label="Menu" hidden>
  <div class="mobile-top">
    <a class="brand" href="<?php echo esc_url( moinet_url( 'accueil', '' ) ); ?>" aria-label="Accueil"><img src="<?php echo esc_url( moinet_asset( 'img/logo-moinet.png' ) ); ?>" alt="" width="350" height="234" style="width:76px"></a>
    <button class="icon-btn nav-close" type="button" aria-label="Fermer le menu"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="m5.5 5.5 13 13M18.5 5.5l-13 13"/></svg></button>
  </div>
  <nav aria-label="Navigation mobile">
    <ul>
      <li><a href="<?php echo esc_url( moinet_url( 'accueil', '' ) ); ?>"<?php moinet_current( 'accueil' ); ?>>Accueil</a></li>
      <li><a href="<?php echo esc_url( moinet_url( 'maison', '' ) ); ?>"<?php moinet_current( 'maison' ); ?>>La Maison</a></li>
      <li><a href="<?php echo esc_url( moinet_url( 'savoir-faire', '' ) ); ?>"<?php moinet_current( 'savoir-faire' ); ?>>Savoir-faire</a></li>
      <li><a href="<?php echo esc_url( moinet_url( 'boutique', '' ) ); ?>"<?php moinet_current( 'boutique' ); ?>>Boutique en ligne</a></li>
      <li><a href="<?php echo esc_url( moinet_url( 'magasins', '' ) ); ?>"<?php moinet_current( 'magasins' ); ?>>Nos boutiques</a></li>
      <li><a href="<?php echo esc_url( moinet_url( 'contact', '' ) ); ?>"<?php moinet_current( 'contact' ); ?>>Contact</a></li>
    </ul>
  </nav>
  <div class="mobile-foot">
    <a class="btn" href="<?php echo esc_url( moinet_url( 'boutique', '' ) ); ?>">Commander en ligne</a>
    <a class="btn btn--ghost" href="<?php echo esc_url( home_url( '/mon-compte/' ) ); ?>">Mon compte</a>
  </div>
</div>
<main id="contenu">
