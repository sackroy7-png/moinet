<?php
/* Généré par _src/wordpress.py depuis maison.html : ne pas modifier ici. */
defined( 'ABSPATH' ) || exit;
get_header(); ?>
<section class="page-hero page-hero--photo" data-enter>
  <div class="hero-frame hero-frame--page" data-plx>
    <img class="hero-photo" src="<?php echo esc_url( moinet_asset( 'img/maison-2.webp' ) ); ?>" width="1500" height="1000" fetchpriority="high"
         alt="Intérieur d’une boutique Moinet : comptoirs de bonbons, boîtes en fer et bocaux.">
    <div class="hero-copy">
      <nav class="breadcrumb" aria-label="Fil d’Ariane"><ol><li><a href="<?php echo esc_url( moinet_url( 'accueil', '' ) ); ?>">Accueil</a></li><li aria-current="page">La Maison</li></ol></nav>
      <h1>Une maison, une famille, sept générations</h1>
      <p class="lead">La Maison Moinet est la plus ancienne confiserie de Vichy toujours en activité&nbsp;: l’unique fabrique familiale, artisanale, indépendante et locale de la ville.</p>
    </div>
  </div>
</section>

<section class="section screen" aria-labelledby="aujourdhui">
  <div class="wrap">
    <div class="section-head">
      <p class="eyebrow">Aujourd’hui</p>
      <h2 id="aujourdhui">Moinet, c’est…</h2>
      <p class="muted">La Maison a su évoluer au fil des années en développant sa production et en diversifiant ses points de vente. Elle est dirigée en binôme par Gilles Michaille et Elisabeth Moinet-Michaille.</p>
    </div>
    <div class="stats">
      <div><strong>1</strong><span>direction familiale en binôme</span></div>
      <div><strong>3</strong><span>sites de production dans le bassin de Vichy</span></div>
      <div><strong>6</strong><span>boutiques à Vichy, Clermont-Ferrand et Paris</span></div>
      <div><strong>40</strong><span>salariés</span></div>
    </div>
  </div>
</section>

<section class="section section--paper" id="histoire" aria-labelledby="histoire-title">
  <div class="wrap">
    <div class="section-head section-head--split">
      <div>
        <h2 id="histoire-title">Une affaire de famille</h2>
      </div>
      <p class="muted">Plusieurs générations ont apporté leur pierre à l’édifice familial, de l’atelier de l’arrière-boutique à la pastillerie du Bioparc.</p>
    </div>
    <div class="gen-list" data-trace>
      <article class="gen">
        <div class="gen-head"><time datetime="1852">1852</time><h3>Jules &amp; Marie Madeleine</h3><span>Fondateurs</span></div>
        <div>
          <p>La Maison Moinet voit le jour en 1852 à Vichy. Jules Rondepierre épouse Marie Madeleine Moinet. Ils s’installent rue de la Source de l’Hôpital dans un immeuble dont le rez-de-chaussée est occupé par la confiserie.</p>
          <p>La production est alors exclusivement artisanale, effectuée dans l’atelier de l’arrière-boutique — l’atelier et la boutique sont encore aujourd’hui le cœur historique de la Maison Moinet.</p>
        </div>
      </article>
      <article class="gen">
        <div class="gen-head"><time datetime="1895">1895</time><h3>Henri &amp; Juliette</h3><span>Reprise de la direction</span></div>
        <div><p>Henri Moinet reprend la direction familiale en 1895. En 1905, il épouse Juliette Mangot. Ils ont deux enfants, Laurent Henri et Rémi, nés respectivement en 1905 et 1906.</p></div>
      </article>
      <article class="gen">
        <div class="gen-head"><time datetime="1924">1924</time><h3>Rémi &amp; Marguerite</h3><span>La Source Roger</span></div>
        <div>
          <p>À la mort de son père en 1924, Rémi lui succède. Durant deux ans, il part faire son service militaire&nbsp;; sa mère Juliette assure l’activité de l’entreprise et diversifie la gamme de bonbons en 1929. La même année, Rémi épouse Marguerite Jourdan, fille de propriétaire vichyssois. Ils auront un enfant, Jean-Claude, en 1930.</p>
          <p>Marguerite s’occupe de la gestion du magasin, du conditionnement, des boîtages et de la vente, comme la plupart des femmes de la famille. En 1932, Rémi achète la Source Roger à Hauterive, à côté de Vichy. L’année suivante, il fait édifier un bâtiment autour de la source et s’équipe pour évaporer l’eau du Bassin de Vichy et en extraire les sels minéraux utilisés dans les fameuses pastilles.</p>
        </div>
      </article>
      <article class="gen">
        <div class="gen-head"><time datetime="1953">1953</time><h3>Jean-Claude &amp; Yvette</h3><span>Pharmaciens</span></div>
        <div>
          <p>Ses parents orientent Jean-Claude vers des études de pharmacie&nbsp;: certaines gommes fabriquées par l’entreprise et destinées aux officines contiennent des substances dont la manipulation nécessite un diplôme de pharmacien. Il épouse en 1953 Yvette Faure, également pharmacienne&nbsp;; ils ont deux enfants, Dominique et Elisabeth.</p>
          <p>Jean-Claude rejoint son père à la direction et crée les Laboratoires Vichy-Santé, proposant une large gamme de pastillages pharmaceutiques et de nombreux produits aux sels minéraux.</p>
        </div>
      </article>
      <article class="gen">
        <div class="gen-head"><time datetime="1989">1989</time><h3>Elisabeth &amp; Gilles</h3><span>De nouvelles boutiques</span></div>
        <div>
          <p>Au décès de Rémi, Jean-Claude voit sa fille Elisabeth et son gendre Gilles Michaille venir l’épauler. Gilles s’occupe de la production, Elisabeth de la boutique rue de la Source de l’Hôpital&nbsp;; elle s’attache en particulier à éditer ou rééditer des boîtes en fer.</p>
          <p>Le couple améliore la commercialisation en ouvrant de nouveaux points de vente à Vichy, Paris et Clermont-Ferrand.</p>
        </div>
      </article>
      <article class="gen">
        <div class="gen-head"><time datetime="2017">2017</time><h3>Lucas &amp; Colin</h3><span>7<sup>e</sup> génération</span></div>
        <div><p>Leurs fils, Lucas et Colin, représentent la septième génération Moinet-Michaille. Lucas occupe depuis janvier 2017 le poste de responsable de la production.</p></div>
      </article>
    </div>
  </div>
</section>

<section class="section screen" aria-labelledby="archives-title">
  <div class="wrap">
    <div class="section-head section-head--split">
      <h2 id="archives-title">Les archives de la maison</h2>
      <p class="muted">Cartes postales, camionnette de livraison et ateliers&nbsp;: un siècle et demi de confiserie à Vichy.</p>
    </div>
  </div>
  <div class="archives" data-drift="fine" tabindex="0" role="group" aria-label="Photographies d’archives de la maison">
    <div class="archives-row">
      <img src="<?php echo esc_url( moinet_asset( 'img/histoire-1.webp' ) ); ?>" alt="Carte postale ancienne d’une rue commerçante de Vichy." loading="lazy" width="1300" height="874">
      <img src="<?php echo esc_url( moinet_asset( 'img/histoire-3.webp' ) ); ?>" alt="Camionnette ancienne peinte aux couleurs des bonbons de H. Moinet." loading="lazy" width="1300" height="926">
      <img src="<?php echo esc_url( moinet_asset( 'img/histoire-5.webp' ) ); ?>" alt="Atelier de fabrication ancien, en noir et blanc." loading="lazy" width="1300" height="880">
      <img src="<?php echo esc_url( moinet_asset( 'img/histoire-6.webp' ) ); ?>" alt="Ouvrières conditionnant des bonbons dans un atelier, photographie en couleur." loading="lazy" width="1300" height="867">
    </div>
  </div>
</section>

<section class="section section--ink griffe" aria-labelledby="identite-title">
  <div class="wrap section-head section-head--split">
    <div>
      <h2 id="identite-title">La griffe Moinet</h2>
    </div>
    <div>
      <p>La création de la griffe remonte aux années 1930. Rémi Moinet, doté d’un sens aigu de la publicité, dessine plusieurs maquettes de boîtes et prospectus entre les années 1930 et 1950. Féru d’histoire, amateur de gravure et bibliophile, il devient l’un des plus fidèles clients et amis du graveur Paul Devaux, à qui il commande des boîtes représentant Vichy à différentes époques — Art Déco, Ancien Régime, Médiéval ou Féodal.</p>
    </div>
  </div>
  <div class="fan" data-fan>
    <div class="fan-ambient" aria-hidden="true"></div>
    <ul class="fan-stage">
      <li class="fan-item"><img src="<?php echo esc_url( moinet_asset( 'img/identite-2.webp' ) ); ?>" alt="Boîte ronde ornée de blasons, marquée Vichy 1852." loading="lazy" width="1100" height="845"></li>
      <li class="fan-item"><img src="<?php echo esc_url( moinet_asset( 'img/identite-6.webp' ) ); ?>" alt="Boîte ronde « Praline Vichy » décorée de roses de style Art Déco." loading="lazy" width="1100" height="901"></li>
      <li class="fan-item"><img src="<?php echo esc_url( moinet_asset( 'img/identite-1.webp' ) ); ?>" alt="Boîte cylindrique de sucres d’orge digestifs Vichy-Santé." loading="lazy" width="1100" height="970"></li>
      <li class="fan-item"><img src="<?php echo esc_url( moinet_asset( 'img/identite-5.webp' ) ); ?>" alt="Boîte ronde orange « Les bonbons de Vichy de H. Moinet »." loading="lazy" width="1100" height="885"></li>
      <li class="fan-item"><img src="<?php echo esc_url( moinet_asset( 'img/identite-3.webp' ) ); ?>" alt="Papier illustré « Les Bonbons du Pays Bourbonnais de H. Moinet »." loading="lazy" width="1100" height="755"></li>
      <li class="fan-item"><img src="<?php echo esc_url( moinet_asset( 'img/identite-4.webp' ) ); ?>" alt="Carton publicitaire jaune « les bonbons de H. Moinet »." loading="lazy" width="1100" height="740"></li>
    </ul>
    <div class="fan-names" role="group" aria-label="Choisir une pièce de la collection">
      <button type="button" class="fan-name" aria-pressed="true">Vichy 1852</button>
      <button type="button" class="fan-name" aria-pressed="false">Praline Vichy</button>
      <button type="button" class="fan-name" aria-pressed="false">Vichy-Santé</button>
      <button type="button" class="fan-name" aria-pressed="false">Les bonbons de Vichy</button>
      <button type="button" class="fan-name" aria-pressed="false">Pays Bourbonnais</button>
      <button type="button" class="fan-name" aria-pressed="false">Pour votre plaisir</button>
    </div>
    <div class="fan-nav">
      <button type="button" data-fan-prev aria-label="Pièce précédente"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M14.5 5.5 8 12l6.5 6.5"/></svg></button>
      <button type="button" data-fan-next aria-label="Pièce suivante"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M9.5 5.5 16 12l-6.5 6.5"/></svg></button>
    </div>
  </div>
</section>

<section class="section screen" id="production" aria-labelledby="production-title">
  <div class="wrap">
    <div class="section-head">
      <h2 id="production-title">Trois sites dans le bassin de Vichy</h2>
    </div>
    <div class="gen-list" data-trace>
      <article class="gen">
        <div class="gen-head"><time datetime="1852">1852</time><h3>Atelier historique</h3><span>Vichy</span></div>
        <div><p>Depuis 1852, l’atelier de fabrication est situé dans l’arrière-boutique, rue de la Source de l’Hôpital. On y fabrique toujours, de manière artisanale, les bonbons glacés, nougats, caramels, pralines et chocolats.</p></div>
      </article>
      <article class="gen">
        <div class="gen-head"><time datetime="1932">1932</time><h3>Usine historique</h3><span>Source Roger, Hauterive</span></div>
        <div>
          <p>Une usine est édifiée autour de la Source Roger afin d’extraire les sels minéraux nécessaires à la fabrication des pastilles&nbsp;; une grande partie de la production s’y établit. L’arrivée de Gilles Michaille en 1989 contribue à augmenter la production de pastilles.</p>
          <p>À partir de 1996, Moinet se lance également dans les produits à marques distributeurs et les produits terroirs distribués en grandes et moyennes surfaces.</p>
        </div>
      </article>
      <article class="gen">
        <div class="gen-head"><time datetime="1998">1998</time><h3>Usine du Bioparc</h3><span>Hauterive</span></div>
        <div class="split" style="align-items:start">
          <div>
            <p>Une nouvelle pastillerie s’implante sur la zone d’activité du Bioparc d’Hauterive, à deux pas de l’usine historique&nbsp;: 1&nbsp;440&nbsp;m² au sol (1&nbsp;860&nbsp;m² au total) sur deux niveaux, répartis entre fabrication, conditionnement et stockage.</p>
            <p>Lancée en 1999, la production de pastilles sur ce site passe de 320 tonnes en 1991 à 850 tonnes en 2001.</p>
          </div>
          <img class="cut" src="<?php echo esc_url( moinet_asset( 'img/maison-4.webp' ) ); ?>" alt="Bâtiment blanc et bleu de la pastillerie Moinet au Bioparc d’Hauterive." loading="lazy" width="1500" height="1000">
        </div>
      </article>
    </div>
  </div>
</section>

<section class="section screen section--paper" id="points-de-vente" aria-labelledby="pdv-title">
  <div class="wrap split">
    <div>
      <h2 id="pdv-title">Fabricant et commerçant</h2>
      <p class="muted">La Maison Moinet a toujours souhaité conserver cette double casquette. Ses boutiques se sont multipliées au fil du temps.</p>
      <a class="btn" href="<?php echo esc_url( moinet_url( 'magasins', '' ) ); ?>">Adresses et horaires</a>
    </div>
    <ol class="chrono">
      <li><time datetime="1852">Depuis 1852</time><span><strong>Confiserie Moinet</strong>, 4 rue de la Source de l’Hôpital, Vichy. La boutique historique.</span></li>
      <li><time datetime="1993">Depuis 1993</time><span><strong>Côté Sucré</strong>, 11 rue Georges-Clemenceau, Vichy.</span></li>
      <li><time datetime="2015">Depuis 2015</time><span><strong>Maison Moinet</strong>, 45 rue Saint-Louis-en-l’Île, Paris. Première boutique parisienne, à deux pas de Notre-Dame.</span></li>
      <li><time datetime="2016">Depuis 2016</time><span><strong>Confiserie Moinet</strong>, 1 place Royale, Clermont-Ferrand. Boutique de style Art nouveau, inscrite à l’Inventaire supplémentaire des monuments historiques depuis 1986.</span></li>
      <li><time datetime="2017-08">Depuis 2017</time><span><strong>La Galerie des Glaces</strong>, 1 rue Georges-Clemenceau, Vichy. Glaces artisanales.</span></li>
      <li><time datetime="2026-03">Depuis 2026</time><span><strong>La Pastillerie Moinet</strong>, 2 rue Président Roosevelt, Vichy. Boutique dédiée aux pastilles et à l’univers Moinet.</span></li>
    </ol>
  </div>
</section>
<?php get_footer();
