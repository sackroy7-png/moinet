<?php
/* Généré par _src/wordpress.py depuis magasins.html : ne pas modifier ici. */
defined( 'ABSPATH' ) || exit;
get_header(); ?>
<script type="application/ld+json">{"@context": "https://schema.org", "@graph": [{"@type": "Store", "name": "Confiserie Moinet – Vichy", "parentOrganization": {"@type": "Organization", "name": "Confiserie Moinet"}, "address": {"@type": "PostalAddress", "streetAddress": "4, rue de la Source de l’Hôpital", "postalCode": "03200", "addressLocality": "Vichy", "addressCountry": "FR"}, "openingHours": ["Mo-Sa 09:30-12:00", "Mo-Sa 14:30-19:00"], "telephone": "+33 4 70 32 31 77"}, {"@type": "Store", "name": "Côté Sucré – Vichy", "parentOrganization": {"@type": "Organization", "name": "Confiserie Moinet"}, "address": {"@type": "PostalAddress", "streetAddress": "11, rue Georges-Clemenceau", "postalCode": "03200", "addressLocality": "Vichy", "addressCountry": "FR"}, "openingHours": ["Mo 11:00-12:00", "Mo 15:00-19:00", "Tu-Sa 09:00-19:00", "Su 10:15-12:15", "Su 15:00-19:00"], "telephone": "+33 4 70 31 97 89"}, {"@type": "Store", "name": "Pastillerie Moinet – Vichy", "parentOrganization": {"@type": "Organization", "name": "Confiserie Moinet"}, "address": {"@type": "PostalAddress", "streetAddress": "2, rue Président Roosevelt", "postalCode": "03200", "addressLocality": "Vichy", "addressCountry": "FR"}, "openingHours": ["We-Sa 11:00-13:00", "We-Sa 14:00-19:00", "Su 15:00-19:00"]}, {"@type": "Store", "name": "La Galerie des Glaces – Vichy", "parentOrganization": {"@type": "Organization", "name": "Confiserie Moinet"}, "address": {"@type": "PostalAddress", "streetAddress": "1, rue Georges-Clemenceau", "postalCode": "03200", "addressLocality": "Vichy", "addressCountry": "FR"}, "openingHours": ["We-Su 13:00-19:00"]}, {"@type": "Store", "name": "Confiserie Moinet – Clermont-Ferrand", "parentOrganization": {"@type": "Organization", "name": "Confiserie Moinet"}, "address": {"@type": "PostalAddress", "streetAddress": "1, place Royale", "postalCode": "63000", "addressLocality": "Clermont-Ferrand", "addressCountry": "FR"}, "openingHours": ["Tu-Sa 11:00-13:00", "Tu-Sa 14:00-19:00"], "telephone": "+33 4 73 24 20 91"}, {"@type": "Store", "name": "Maison Moinet – Paris", "parentOrganization": {"@type": "Organization", "name": "Confiserie Moinet"}, "address": {"@type": "PostalAddress", "streetAddress": "45, rue Saint-Louis-en-l’Île", "postalCode": "75004", "addressLocality": "Paris", "addressCountry": "FR"}, "openingHours": ["Tu-Sa 11:00-13:30", "Tu-Sa 14:30-19:00"], "telephone": "+33 1 42 02 87 18"}]}</script><section class="page-hero page-hero--photo" data-enter>
  <div class="hero-frame hero-frame--page" data-plx>
    <img class="hero-photo" src="<?php echo esc_url( moinet_asset( 'img/maison-3.webp' ) ); ?>" width="1500" height="1146" fetchpriority="high" style="object-position: 62% 40%"
         alt="Devanture d’une boutique Moinet vue derrière une fontaine sculptée, l’inscription « les bonbons Moinet confiseur » sur la vitrine.">
    <div class="hero-copy">
      <nav class="breadcrumb" aria-label="Fil d’Ariane"><ol><li><a href="<?php echo esc_url( moinet_url( 'accueil', '' ) ); ?>">Accueil</a></li><li aria-current="page">Nos boutiques</li></ol></nav>
      <h1>Nos six boutiques</h1>
      <p class="lead">De la boutique historique de 1852 au décor Art nouveau de la place Royale, venez découvrir nos douceurs sur place.</p>
      <nav aria-label="Aller à une ville" class="hero-ctas" style="margin-top:1.5rem">
        <a class="btn btn--ghost btn--sm" href="#vichy-historique">Vichy</a>
        <a class="btn btn--ghost btn--sm" href="#clermont">Clermont-Ferrand</a>
        <a class="btn btn--ghost btn--sm" href="#paris">Paris</a>
      </nav>
    </div>
  </div>
</section>
<section class="section section--tight" aria-labelledby="liste-title">
  <h2 id="liste-title" class="visually-hidden">Adresses et horaires des boutiques</h2>
  <div class="wrap stores">
  <article class="store" id="vichy-historique">
    <div class="store-img"><img src="<?php echo esc_url( moinet_asset( 'img/shop-vichy.webp' ) ); ?>" alt="Devanture rouge de la Confiserie Moinet, rue de la Source de l’Hôpital à Vichy." loading="lazy" width="1200" height="800"></div>
    <div class="store-body">
      <span class="store-city">Vichy</span>
      <h3>Confiserie Moinet</h3>
      <p class="since">La boutique historique, depuis 1852</p>
      <address>4, rue de la Source de l’Hôpital<br>03200 Vichy</address>
      <dl class="hours"><dt>Du lundi au samedi</dt><dd>9h30–12h et 14h30–19h</dd><dt>Dimanches d’août</dt><dd>10h15–12h15 et 15h–19h</dd></dl>
      <div class="store-actions"><a href="https://www.google.com/maps/search/?api=1&query=Confiserie%20Moinet%204%2C%20rue%20de%20la%20Source%20de%20l%E2%80%99H%C3%B4pital%2C%2003200%20Vichy" rel="noopener">Itinéraire</a><a href="tel:+33470323177">Appeler le 04 70 32 31 77</a></div>
    </div>
  </article>
  <article class="store" id="cote-sucre">
    <div class="store-img"><img src="<?php echo esc_url( moinet_asset( 'img/shop-cotesucre.webp' ) ); ?>" alt="Vitrine de la boutique Côté Sucré à Vichy." loading="lazy" width="1200" height="800"></div>
    <div class="store-body">
      <span class="store-city">Vichy</span>
      <h3>Côté Sucré</h3>
      <p class="since">Depuis 1993</p>
      <address>11, rue Georges-Clemenceau<br>03200 Vichy</address>
      <dl class="hours"><dt>Lundi</dt><dd>11h–12h et 15h–19h</dd><dt>Du mardi au samedi</dt><dd>9h–19h</dd><dt>Dimanche</dt><dd>10h15–12h15 et 15h–19h</dd></dl>
      <div class="store-actions"><a href="https://www.google.com/maps/search/?api=1&query=C%C3%B4t%C3%A9%20Sucr%C3%A9%2011%2C%20rue%20Georges-Clemenceau%2C%2003200%20Vichy" rel="noopener">Itinéraire</a><a href="tel:+33470319789">Appeler le 04 70 31 97 89</a></div>
    </div>
  </article>
  <article class="store" id="pastillerie">
    <div class="store-img"><img src="<?php echo esc_url( moinet_asset( 'img/shop-pastillerie.webp' ) ); ?>" alt="Entrée de la Pastillerie Moinet, rue Président Roosevelt à Vichy." loading="lazy" width="765" height="1020"></div>
    <div class="store-body">
      <span class="store-city">Vichy</span>
      <h3>Pastillerie Moinet</h3>
      <p class="since">Depuis mars 2026, pastilles et univers Moinet</p>
      <address>2, rue Président Roosevelt<br>03200 Vichy</address>
      <dl class="hours"><dt>Du mercredi au samedi</dt><dd>11h–13h et 14h–19h</dd><dt>Dimanche</dt><dd>15h–19h</dd></dl>
      <div class="store-actions"><a href="https://www.google.com/maps/search/?api=1&query=Pastillerie%20Moinet%202%2C%20rue%20Pr%C3%A9sident%20Roosevelt%2C%2003200%20Vichy" rel="noopener">Itinéraire</a></div>
    </div>
  </article>
  <article class="store" id="galerie-des-glaces">
    <div class="store-img"><img src="<?php echo esc_url( moinet_asset( 'img/shop-glaces.webp' ) ); ?>" alt="Façade de La Galerie des Glaces à Vichy." loading="lazy" width="1200" height="800"></div>
    <div class="store-body">
      <span class="store-city">Vichy</span>
      <h3>La Galerie des Glaces</h3>
      <p class="since">Glaces artisanales, depuis 2017</p>
      <address>1, rue Georges-Clemenceau<br>03200 Vichy</address>
      <dl class="hours"><dt>Du mercredi au dimanche</dt><dd>13h–19h</dd></dl>
      <div class="store-actions"><a href="https://www.google.com/maps/search/?api=1&query=La%20Galerie%20des%20Glaces%201%2C%20rue%20Georges-Clemenceau%2C%2003200%20Vichy" rel="noopener">Itinéraire</a></div>
    </div>
  </article>
  <article class="store" id="clermont">
    <div class="store-img"><img src="<?php echo esc_url( moinet_asset( 'img/shop-clermont.webp' ) ); ?>" alt="Façade Art nouveau de la Confiserie Moinet, place Royale à Clermont-Ferrand." loading="lazy" width="1200" height="800"></div>
    <div class="store-body">
      <span class="store-city">Clermont-Ferrand</span>
      <h3>Confiserie Moinet</h3>
      <p class="since">Depuis 2016, décor Art nouveau inscrit aux monuments historiques</p>
      <address>1, place Royale<br>63000 Clermont-Ferrand</address>
      <dl class="hours"><dt>Du mardi au samedi</dt><dd>11h–13h et 14h–19h</dd></dl>
      <div class="store-actions"><a href="https://www.google.com/maps/search/?api=1&query=Confiserie%20Moinet%201%2C%20place%20Royale%2C%2063000%20Clermont-Ferrand" rel="noopener">Itinéraire</a><a href="tel:+33473242091">Appeler le 04 73 24 20 91</a></div>
    </div>
  </article>
  <article class="store" id="paris">
    <div class="store-img"><img src="<?php echo esc_url( moinet_asset( 'img/shop-paris.webp' ) ); ?>" alt="Devanture rouge de la Maison Moinet, rue Saint-Louis-en-l’Île à Paris." loading="lazy" width="1200" height="800"></div>
    <div class="store-body">
      <span class="store-city">Paris</span>
      <h3>Maison Moinet</h3>
      <p class="since">Depuis 2015, à deux pas de Notre-Dame</p>
      <address>45, rue Saint-Louis-en-l’Île<br>75004 Paris</address>
      <dl class="hours"><dt>Du mardi au samedi</dt><dd>11h–13h30 et 14h30–19h</dd><dt>Dimanche</dt><dd>Fermé (ouverture certains dimanches, 14h30–18h)</dd></dl>
      <div class="store-actions"><a href="https://www.google.com/maps/search/?api=1&query=Maison%20Moinet%2045%2C%20rue%20Saint-Louis-en-l%E2%80%99%C3%8Ele%2C%2075004%20Paris" rel="noopener">Itinéraire</a><a href="tel:+33142028718">Appeler le 01 42 02 87 18</a></div>
    </div>
  </article>
  </div>
  <p class="wrap shop-note" style="margin-top:2rem">Horaires susceptibles d’évoluer selon les saisons et les jours fériés. Pour toute question&nbsp;: <a href="mailto:contact@confiserie-moinet.fr">contact@confiserie-moinet.fr</a>.</p>
</section>
<?php get_footer();
