<?php
/* Généré par _src/wordpress.py depuis savoir-faire.html : ne pas modifier ici. */
defined( 'ABSPATH' ) || exit;
get_header(); ?>
<section class="page-hero page-hero--photo" data-enter>
  <div class="hero-frame hero-frame--page" data-plx>
    <img class="hero-photo" src="<?php echo esc_url( moinet_asset( 'img/savoir-3.webp' ) ); ?>" width="1500" height="1000" fetchpriority="high"
         alt="Boîte ronde garnie de pastilles, de sucres d’orge et de gommes, entourée de couvercles illustrés « Les bonbons de Vichy de H. Moinet ».">
    <div class="hero-copy">
      <nav class="breadcrumb" aria-label="Fil d’Ariane"><ol><li><a href="<?php echo esc_url( moinet_url( 'accueil', '' ) ); ?>">Accueil</a></li><li aria-current="page">Savoir-faire</li></ol></nav>
      <h1>Made in France, et même made in Auvergne</h1>
      <p class="lead">Moinet assure une fabrication artisanale et française depuis 1852, transmise de génération en génération.</p>
    </div>
  </div>
</section>

<section class="section screen" aria-labelledby="main-title">
  <div class="wrap split">
    <div class="split-media"><div class="frame cut cut-lg" data-plx><img src="<?php echo esc_url( moinet_asset( 'img/savoir-tdl.webp' ) ); ?>" width="1024" height="682" loading="lazy"
      alt="Main d’un confiseur trempant des bonbons un à un dans un poêlon en cuivre, à côté d’une plaque de bonbons alignés."></div></div>
    <div class="prose">
      <h2 id="main-title">Comme de véritables bijoux</h2>
      <p class="dropcap">Les bonbons glacés sont fabriqués à la main, un à un. Leur réalisation, très technique, nécessite plusieurs étapes de façonnage.</p>
      <p>Il en va de même pour les <strong>nougats, caramels et pralines</strong>, toujours élaborés de manière traditionnelle. Enfin, tous les <strong>chocolats</strong> — tablettes, mendiants, ballotins ou sujets de Pâques et de Noël — sont façonnés de manière artisanale.</p>
      <a class="link-arrow" href="<?php echo esc_url( moinet_url( 'boutique', '?cat=bonbons-glaces' ) ); ?>">Découvrir les bonbons glacés</a>
    </div>
  </div>
</section>

<div class="vichy" aria-hidden="true"></div>

<section class="section screen section--paper" aria-labelledby="pastilles-title">
  <div class="wrap split split--rev">
    <div class="split-media split-media--pastille">
      <div class="frame cut" data-plx><img src="<?php echo esc_url( moinet_asset( 'img/savoir-2.webp' ) ); ?>" width="1500" height="1000" loading="lazy"
        alt="Gros plan sur des pastilles octogonales blanches gravées « Bassin de Vichy »."></div>
      <div class="spin-pastille" data-pastille aria-hidden="true">
        <img class="pastille-still" src="<?php echo esc_url( moinet_asset( 'img/pastille.webp' ) ); ?>" width="720" height="720" alt="" loading="lazy">
        <canvas class="pastille-canvas"></canvas>
      </div>
    </div>
    <div class="prose">
      <p class="eyebrow">80&nbsp;% de notre production</p>
      <h2 id="pastilles-title">Les pastilles du Bassin de Vichy</h2>
      <p>Les sels minéraux extraits de l’eau de source sont la base de la fabrication des pastilles. C’est en 1932 que Rémi Moinet achète la <strong>Source Roger</strong>, située sur le Bassin de Vichy, et débute la fabrication de ses propres pastilles.</p>
      <p>La gamme est diversifiée&nbsp;: <strong>anis, citron, orange</strong>, en plus de la traditionnelle pastille à la <strong>menthe</strong>. Moinet décline également des pastilles <strong>sans sucre</strong> et des <strong>mini-pastilles</strong>.</p>
      <div class="hero-ctas" style="margin-top:1.5rem">
        <a class="btn" href="<?php echo esc_url( moinet_url( 'boutique', '?cat=pastilles' ) ); ?>">Les pastilles</a>
        <a class="btn btn--ghost" href="<?php echo esc_url( moinet_url( 'boutique', '?cat=pastilles-sans-sucre' ) ); ?>">Sans sucre</a>
      </div>
    </div>
  </div>
</section>

<section class="section screen" aria-labelledby="selection-title">
  <div class="wrap">
    <div class="section-head section-head--split">
      <div>
        <h2 id="selection-title">Une gamme de spécialités régionales</h2>
      </div>
      <p class="muted">Sucres d’orge de Vichy, pâtes de fruits d’Auvergne, bonbons glacés du pays bourbonnais, menthe fondante, fondants aux fruits, gommes véritables, marrons glacés, gels de fruits, sucres cuits, chocolats, caramels, nougats, pralines.</p>
    </div>
    <div class="mosaic" style="grid-auto-flow: dense" data-parallax>
      <a class="tile tile--wide" href="<?php echo esc_url( moinet_url( 'boutique', '?cat=sucres-cuits' ) ); ?>"><img src="<?php echo esc_url( moinet_asset( 'img/cat-sucres-cuits.webp' ) ); ?>" alt="" loading="lazy" width="1200" height="600"><span class="tile-label"><span>Vichy</span><strong>Sucres d’orge</strong></span></a>
      <a class="tile" href="<?php echo esc_url( moinet_url( 'boutique', '?cat=pate-de-fruits' ) ); ?>"><img src="<?php echo esc_url( moinet_asset( 'img/cat-pate-de-fruits.webp' ) ); ?>" alt="" loading="lazy" width="800" height="533"><span class="tile-label"><span>Auvergne</span><strong>Pâtes de fruits</strong></span></a>
      <a class="tile" href="<?php echo esc_url( moinet_url( 'boutique', '?cat=marrons-glaces' ) ); ?>"><img src="<?php echo esc_url( moinet_asset( 'img/cat-marrons-glaces.webp' ) ); ?>" alt="" loading="lazy" width="1200" height="628"><span class="tile-label"><span>Fêtes</span><strong>Marrons glacés</strong></span></a>
      <a class="tile" href="<?php echo esc_url( moinet_url( 'boutique', '?cat=gels-de-fruits' ) ); ?>"><img src="<?php echo esc_url( moinet_asset( 'img/cat-gels-de-fruits.webp' ) ); ?>" alt="" loading="lazy" width="1200" height="600"><span class="tile-label"><span>Fruités</span><strong>Gels de fruits</strong></span></a>
      <a class="tile" href="<?php echo esc_url( moinet_url( 'boutique', '?cat=pralines' ) ); ?>"><img src="<?php echo esc_url( moinet_asset( 'img/cat-pralines.webp' ) ); ?>" alt="" loading="lazy" width="1200" height="600"><span class="tile-label"><span>Tradition</span><strong>Pralines</strong></span></a>
      <a class="tile tile--wide" href="<?php echo esc_url( moinet_url( 'boutique', '?cat=tablettes-de-chocolat' ) ); ?>"><img src="<?php echo esc_url( moinet_asset( 'img/cat-tablettes-de-chocolat.webp' ) ); ?>" alt="" loading="lazy" width="1200" height="800"><span class="tile-label"><span>Lait, noir, pastilles</span><strong>Tablettes de chocolat</strong></span></a>
    </div>
  </div>
</section>

<section class="cta-band" aria-labelledby="cta-title">
  <img src="<?php echo esc_url( moinet_asset( 'img/eboutique.webp' ) ); ?>" alt="" loading="lazy" width="1600" height="500">
  <div class="wrap">
    <div><h2 id="cta-title">Goûtez la différence</h2><p>Retrouvez nos douceurs en boutique à Vichy, Clermont-Ferrand et Paris, ou directement en ligne.</p></div>
    <a class="btn btn--light" href="<?php echo esc_url( moinet_url( 'boutique', '' ) ); ?>">Commander en ligne</a>
    <p class="close-word" aria-hidden="true">Made in Auvergne</p>
  </div>
</section>
<?php get_footer();
